import React from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Book from "./RedditRender";
import TabPanel from "./TabPanel";

export default function Reddit() {
  return (
    <div>
      <TabPanel />
    </div>
  );
}
