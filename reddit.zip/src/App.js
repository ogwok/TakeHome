import React from "react";
import Reddit from "./Reddit";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Reddit />
    </div>
  );
}

export default App;
