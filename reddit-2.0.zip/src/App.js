import React from "react";
import Reddit from "./Reddit";
import "./App.css";
// import CardComp from "./CardComp";

function App() {
  return (
    <div className="App">
      <Reddit />
      {/* <CardComp /> */}
    </div>
  );
}

export default App;
